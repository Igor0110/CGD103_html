function $id(id) {
  //$id("btnLeft")
  return document.getElementById(id); //document.getElementById("btnLeft")
}

window.addEventListener("load", function () {
  let wrap = document.querySelector(".wrap");
  let curIndex = 0;
  //-----------------------------------------btnLeft.onclick
  $id("btnLeft").onclick = function () {
    $id("btnRight").disabled = false;
    if ($id("btnLeft").disabled) {
      return;
    } else if (curIndex === 1) {
      curIndex--;
      $id("btnLeft").disabled = true;
      document.querySelector(`.item:nth-child(${curIndex})`).style.display =
        "block";
    } else {
      curIndex--;
      document.querySelector(`.item:nth-child(${curIndex})`).style.display =
        "block";
    }
  };
  //-----------------------------------------btnRight.onclick
  $id("btnRight").onclick = function () {
    $id("btnLeft").disabled = false;

    if ($id("btnRight").disabled) {
      return;
    } else if (curIndex === 4) {
      curIndex++;
      $id("btnRight").disabled = true;
      document.querySelector(`.item:nth-child(${curIndex})`).style.display =
        "none";
    } else {
      curIndex++;
      document.querySelector(`.item:nth-child(${curIndex})`).style.display =
        "none";
    }
  };
});
