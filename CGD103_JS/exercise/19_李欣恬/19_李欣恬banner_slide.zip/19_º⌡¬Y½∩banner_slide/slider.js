let i=-1;
let items = document.getElementsByClassName("item");
let btnRight = document.getElementById("btnRight");
let btnLeft = document.getElementById("btnLeft");
function sliderRight(){
    i++;
    while(i<5){
        items[i].style.display="none";

        break;
    }
    if(i!=-1){
        btnLeft.disabled=false;
    }
    if(i===4){
        btnRight.disabled=true;
    }
    console.log(i);
}
function sliderLeft(){
    i--;
    items[i+1].style.display="block";
    if(i===-1){
        btnLeft.disabled=true;
    }
    if(i != 4){
        btnRight.disabled=false;
    }
    
}
function init(){
    let btnRight = document.getElementById("btnRight");
    let btnLeft = document.getElementById("btnLeft");
    btnRight.onclick = sliderRight;
    btnLeft.onclick = sliderLeft;
}
window.addEventListener("load", init, false);