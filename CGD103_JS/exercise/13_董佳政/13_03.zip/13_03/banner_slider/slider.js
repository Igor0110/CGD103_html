// 法一

/* window.addEventListener("load", function () {

    const btnLeft = document.querySelector("#btnLeft");
    const btnRight = document.querySelector("#btnRight");
    const wrap = document.querySelector(".wrap");
    const item = document.querySelectorAll(".item");
    let curIndex = 0;

    btnRight.addEventListener("click", () => {
        curIndex += 1;
        wrap.style.left = `${-curIndex * 310}px`;
        if (curIndex >= 1) {
            btnLeft.disabled = false;
        }

        if (item.length - curIndex === 4) {
            btnRight.disabled = true;
        }
    });

    btnLeft.addEventListener("click", () => {
        curIndex -= 1;
        btnRight.disabled = false;

        if (curIndex === 0) {
            btnLeft.disabled = true;
        }

        
        wrap.style.left = `${-curIndex * 310}px`;
    });
}); */

// 法二

window.addEventListener("load", function () {
    const btnLeft = document.querySelector("#btnLeft");
    const btnRight = document.querySelector("#btnRight");
    const wrap = document.querySelector(".wrap");
    const item = document.querySelectorAll(".item");
    let curIndex = 0;

    function moveItem(e) {
        e.id === "btnRight" ? (curIndex += 1) : (curIndex -= 1);
        wrap.style.left = `${-curIndex * 310}px`;
    }

    function checkBtnRight() {
        return item.length - curIndex === 4
            ? (btnRight.disabled = true)
            : (btnRight.disabled = false);
    }

    function checkBtnLeft() {
        return curIndex > 0
            ? (btnLeft.disabled = false)
            : (btnLeft.disabled = true);
    }

    btnRight.addEventListener("click", (e) => {
        moveItem(e.target);
        checkBtnLeft();
        checkBtnRight();
    });

    btnLeft.addEventListener("click", (e) => {
        moveItem(e.target);
        checkBtnRight();
        checkBtnLeft();
    });
});
