const checkBtn = document.querySelector("#checkBtn");
checkBtn.addEventListener("click", isIdNo);

const number = [
    [1, 0],
    [1, 1],
    [1, 2],
    [1, 3],
    [1, 4],
    [1, 5],
    [1, 6],
    [1, 7],
    [3, 4],
    [1, 8],
    [1, 9],
    [2, 0],
    [2, 1],
    [2, 2],
    [3, 5],
    [2, 3],
    [2, 4],
    [2, 5],
    [2, 6],
    [2, 7],
    [2, 8],
    [2, 9],
    [3, 2],
    [3, 0],
    [3, 1],
    [3, 3],
];

function isIdNo() {
    const idValue = document.querySelector("#text").value;
    if (idValue.length !== 10) {
        alert("身分證不足10碼");
    } else {
        let sum = 0;
        let idArr = idValue.split("");
        idArr.forEach((idletter, index) => {
            if (index === 0) {
                checkFirstLetter(idletter)
                    ? (sum +=
                          number[idletter.toUpperCase().charCodeAt() - 65][0] *
                              1 +
                          number[idletter.toUpperCase().charCodeAt() - 65][1] *
                              9)
                    : alert("第一個字母為A~Z");
            } else if (index === 1) {
                checkSecondLetter(idletter)
                    ? (sum += idletter * 8)
                    : alert("第二個數字只能為1或2");
            } else sum += idletter * (9 - index);
        });
        console.log(sum);
        const checkNumber = 10 - (sum % 10);
        return +idArr[idArr.length - 1] === checkNumber
            ? alert("正確")
            : alert("錯誤");
    }
}

function checkFirstLetter(str) {
    return str.toUpperCase().charCodeAt() >= 65 ||
        str.toUpperCase().charCodeAt() <= 90
        ? true
        : false;
}

function checkSecondLetter(str) {
    return +str >= 1 && +str <= 2 ? true : false;
}
