var orangePerKg = 22;
var time = 8000;

// hw1
document.write("HW1 : ");
document.write(orangePerKg*2);

// hw2

hour = parseInt(time/3600);
minute = parseInt((time/60)%60);
second = parseInt((time%3600)%60);

document.write( "<br>"+ "HW2  Time :");
document.write(hour + ":" + minute + ":" + second +"<br>");

// hw3

total = orangePerKg * 50;
 if (total > 500){
    document.write("HW3 Total : " + total, " discount : "+ total*0.9+"<br>");
 } else {
    document.write("Total : " + total+"<br>");
 }

// hw4

if (total > 1000){
    document.write("HW4 Total : " + total, " discount : "+ total*0.7+"<br>");
} else if(total > 500){
    document.write("HW4 Total : " + total, " discount : "+ total*0.9+"<br>");
} else {
    document.write("Total : " + total+"<br>");
}

// hw5


var purchase = "1";
var kg = 101;
var amount;

switch(purchase){
    case "1":
        amount = kg*30;
        if (kg > 100){
            amount = kg*20;
        }  else if (kg > 40){
            amount = kg * 25;
        }
        break;
    case "2":
        amount = kg*25;
        if(kg > 100){
            amount = kg*15;
        }else if (kg > 40){
            amount = kg *20;
        }
        break;
    case "3":
        amount = kg*20;
        if (kg > 100){
            amount = kg*10;
        }else if (kg > 40){
            amount = kg* 15;
        }
        break;
    default:
        amount = 0;
}

document.write("HW5 Total : ", amount ,"<br>");