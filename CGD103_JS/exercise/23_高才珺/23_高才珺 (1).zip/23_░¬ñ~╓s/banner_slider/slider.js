// function $id(id){  //$id("btnLeft")
//     return document.getElementById(id);  //document.getElementById("btnLeft")
// }


window.addEventListener("load", function(){
    let right = document.getElementById("btnRight");
    let left = document.getElementById("btnLeft");
    let wrap = document.querySelector(".wrap");
    let arr = document.querySelectorAll(".wrap .item img")
    let width = document.querySelector(".item").offsetWidth;
    let mwidth = width+10;
    let curIndex = 0;
    //-----------------------------------------btnLeft.onclick
    right.onclick = function(){
        curIndex++;
        wrap.style.left = "-"+(mwidth*curIndex)+"px";
        if(curIndex == arr.length-5){
            right.disabled = true;
        }else{
            left.disabled = false;
            right.disabled = false;
        }
    }
    //-----------------------------------------btnRight.onclick
    left.onclick = function(){
        curIndex--;
        wrap.style.left = "-"+(mwidth*curIndex)+"px";
        if(curIndex == 0){
            left.disabled = true;
        }else{
            right.disabled = false;
            left.disabled = false;
        }
    }

    // console.log(curIndex);
})
